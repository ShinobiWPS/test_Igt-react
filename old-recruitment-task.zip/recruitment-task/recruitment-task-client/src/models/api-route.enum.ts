export enum ApiRoute {
  SECTIONS = 'sections',
}
