type FooterLink = {
  label: string;
  href: string;
};

export const footerLinks: FooterLink[] = [
  {
    label: 'Link 1',
    href: '/',
  },
  {
    label: 'Link 2',
    href: '/',
  },
  {
    label: 'Link 3',
    href: '/',
  },
  {
    label: 'Link 4',
    href: '/',
  },
  {
    label: 'Link 5',
    href: '/',
  },
  {
    label: 'Link 6',
    href: '/',
  },
];
