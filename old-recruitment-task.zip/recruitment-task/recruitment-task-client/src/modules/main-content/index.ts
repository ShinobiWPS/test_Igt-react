export * from './main-content.component';
