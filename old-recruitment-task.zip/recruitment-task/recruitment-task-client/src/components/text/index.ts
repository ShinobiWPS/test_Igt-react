export * from './text.component';
