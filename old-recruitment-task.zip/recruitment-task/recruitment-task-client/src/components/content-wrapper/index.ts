export * from './content-wrapper.component';
