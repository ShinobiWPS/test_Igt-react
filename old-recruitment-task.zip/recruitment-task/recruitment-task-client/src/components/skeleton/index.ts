export * from './skeleton.component';
